PUBLIC USE 2023 NATIONAL SURVEY OF COLLEGE GRADUATES DATA FILES

This download file contains data and related documentation for the public use 2023 National Survey of College Graduates (NSCG) data files.

The data included in this download file is taken from the September 11, 2025 version of the NSCG data maintained at NSF.

PLEASE NOTE: 
   The geography variables used in the 2023 NSCG data file have been updated from past cycles.
   Please see the enclosed NCSES Taxonomy of Geographic Areas (TOGA) crosswalk table and the list of new variables below.

   Location Description			   Location Variable
   ---------------------------------------------------------
   First bachelor's degree school location BAST_TOGA
   Birthplace location                     BTHST_TOGA
   Associate degree school location        CCST_TOGA
   2nd highest degree school location      D2ST_TOGA
   3rd highest degree school location      D3ST_TOGA
   4th highest degree school location      D4ST_TOGA
   5th highest degree school location      D5ST_TOGA
   Employer location                       EMST_TOGA
   Non-U.S. country of citizenship         FNCCD_TOGA
   Highest degree school location          HDST_TOGA
   High school location                    HSST_TOGA
   Most recent degree school location      MRST_TOGA
   Respondent location                     RESPLO3_TOGA

ERRATA:
   September 2025: Occupation and field of study labels were corrected in the SAS file formats and codebooks of the 2023 NSCG public use files, which were first released on 23 May 2025.
                   Of note, prior to 2023, occupation code 432360 represented all psychologists, including clinical.
                   In 2023, a new code (611150) was introduced for psychologists in health services (e.g., clinical), and code 432360 was updated to represent only research and applied psychologists.

DESCRIPTION OF FILES
--------------------

  Data and Programs
  -----------------

  The microdata are provided in various formats to facilitate their use with many software packages.
  The principal data format that is supported by NSF is SAS.  Technical support by NSF is limited to 
  the data files and the SAS programs listed here. NSF does not provide support to users of SPSS or 
  other packages, as SPSS and these other packages are not available at the agency.

  epcg23.csv - 2023 NSCG data in comma-separated values format
  EPCG23.DAT - 2023 NSCG data in ASCII format
  epcg23.sas7bdat - 2023 NSCG data in SAS for Windows format

  Fpcg23.sas - a text file containing SAS FORMAT assignment statements
  Lpcg23.sas - a text file containing SAS LABEL assignment statements
  Ppcg23.sas - a text file containing SAS PROC FORMAT statements

  Ldpcg23.sps - a text file containing SPSS syntax for loading EPCG23.DAT (ASCII data) into SPSS
     NOTE: Technical support for SPSS users is not provided by NSF. The validity of this file 
           has not been verified by NSF, as SPSS is not available at the agency.

  LAYOUTPCG23.TXT - Input Layout for EPCG23.DAT

  Documentation and Related Files
  -------------------------------
  https://ncses.nsf.gov/surveys/national-survey-college-graduates/2023#technical-notes - Technical notes

  2023-NSCG-21_annotated_7Aug25.pdf - 2023 NSCG questionnaire for new sample members with variable names identified
  2023NSCG_RecodeDocumentation_4Feb25.pdf - 2023 NSCG recode documentation
  TOGA_crosswalk_NSCG23_20250116.xlsx - NCSES Taxonomy of Geographic Areas (TOGA) crosswalk table

  Ppcg23.html - Summary variable codebook in html, 508-compliant format
  Ppcg23.pdf - Summary variable codebook in Adobe PDF format

  Dpcg23.xlsx - Data Dictionary Source/SAS name crosswalk file (EXCEL spreadsheet format)

  README.TXT - this read me file

-----------------------------------------------------------------------------------
If you have any problems opening, accessing or loading these files, please contact:

  National Center for Science and Engineering Statistics
  U.S. National Science Foundation
  2415 Eisenhower Avenue, Suite W14200
  Alexandria, Virginia 22314
  703-292-8780
  ncsesweb@nsf.gov


Sep-22-2025 12:00:00
